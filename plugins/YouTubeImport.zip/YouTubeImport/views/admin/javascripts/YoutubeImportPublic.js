jQuery(window).load(function() {
  jQuery("a img[title="+youtubeImportedThumb+"]").hide();
  
  

});
