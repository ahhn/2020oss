<script>monitorJob(<?php echo js_escape($status_url); ?>, <?php echo $current_step; ?>, <?php echo js_escape($refresh_url); ?>);</script>
<h2><?php echo __("Please wait..."); ?></h2>
<progress style="width:100%;"></progress>