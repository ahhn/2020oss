<?php

interface Export_Entry extends Iterator, ArrayAccess
{
}
