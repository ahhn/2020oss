<?php

class Table_Export_Exporter extends Omeka_Db_Table
{
}
