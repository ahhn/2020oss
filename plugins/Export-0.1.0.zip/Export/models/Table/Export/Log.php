<?php

class Table_Export_Log extends Omeka_Db_Table
{
}
