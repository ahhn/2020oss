<?php echo head(array('title' => __('Create new exporter'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Create new exporter'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
