<?php echo head(array('title' => __('Configure writer'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Configure writer'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
