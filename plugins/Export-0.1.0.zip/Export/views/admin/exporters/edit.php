<?php echo head(array('title' => __('Edit exporter'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Edit exporter'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
