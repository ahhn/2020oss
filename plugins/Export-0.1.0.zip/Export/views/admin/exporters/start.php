<?php echo head(array('title' => __('Start export'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Start export'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
