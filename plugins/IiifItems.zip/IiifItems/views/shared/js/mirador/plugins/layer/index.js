// Exports the "layer" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/layer')
//   ES2015:
//     import 'tinymce/plugins/layer'
require('./plugin.js');