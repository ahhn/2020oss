<?php

/**
 * Table class for cached IIIF JSON data.
 * @package models
 */
class Table_IiifItems_CachedJsonData extends Omeka_Db_Table {
    protected $_target = "CachedJsonData";
    protected $_name = "iiif_items_cached_json_data";
}
