<?php

/**
 * Table class for accessing background job statuses.
 * @package models
 */
class Table_IiifItems_JobStatus extends Omeka_Db_Table {
}
