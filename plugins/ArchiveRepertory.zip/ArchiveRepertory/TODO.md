TODO for "Archive Repertory" (plugin for Omeka)
===============================================

* Add a job to manage changement of folder for collections.
* Extends the collection class with the folder name and with settings.
