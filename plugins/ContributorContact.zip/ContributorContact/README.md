ContributorContact
==================

Supplies administrators with tools to contact contributors in bulk

If you use this plugin, please take a moment to submit feedback about your experience, so we can keep making Omeka better: [User Survey](https://docs.google.com/forms/d/137gcqd84o8xN-gHr_wPmYbZeVduXhTj0Yim0bn0dGaQ/viewform?usp=send_form)
