
# ShortcodeAnyFile
Omeka shortcode to insert an image anywhere  you can setup a shortcode. The image can come from an item or from the images directory in your theme.
