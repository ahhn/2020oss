<?php

class Table_Import_Importer extends Omeka_Db_Table
{
}
