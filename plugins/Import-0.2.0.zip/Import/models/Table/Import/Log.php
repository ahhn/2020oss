<?php

class Table_Import_Log extends Omeka_Db_Table
{
}
