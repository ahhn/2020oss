<?php echo head(array('title' => __('Configure reader'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Configure reader'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
