<?php echo head(array('title' => __('Edit importer'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Edit importer'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
