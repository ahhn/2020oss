<?php echo head(array('title' => __('Start import'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Start import'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
