<?php echo head(array('title' => __('Configure processor'))); ?>

<div id="primary">
    <?php echo flash(); ?>
    <h2><?php echo __('Configure processor'); ?></h2>
    <?php echo $form; ?>
</div>

<?php echo foot(); ?>
