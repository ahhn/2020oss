<?php

interface Import_Entry extends Iterator, ArrayAccess
{
}
