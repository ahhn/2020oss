<?php

class AvantRelationships_RelationshipsController extends Omeka_Controller_AbstractActionController
{
    public function browseRelationshipsAction()
    {
        return;
    }

    public function editRelationshipRulesAction()
    {
        return;
    }

    public function editRelationshipTypesAction()
    {
        return;
    }

    public function updateRelationshipAction()
    {
        return;
    }

    public function updateRelationshipRuleAction()
    {
        return;
    }

    public function updateRelationshipTypeAction()
    {
        return;
    }

    public function validateRelationshipsAction()
    {
        return;
    }
}
