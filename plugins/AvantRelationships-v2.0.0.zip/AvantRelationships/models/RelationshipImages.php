<?php

class RelationshipImages extends Omeka_Record_AbstractRecord
{
    public $item_id;
    public $identifier;
}