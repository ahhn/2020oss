<?php

class RelationshipRules extends Omeka_Record_AbstractRecord
{
    public $description;
    public $rule;
}