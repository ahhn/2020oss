<?php

class Relationships extends Omeka_Record_AbstractRecord
{
    public $relationship_type_id;
    public $source_item_id;
    public $target_item_id;
}