<?php

class Embed extends Omeka_Record_AbstractRecord
{
    public $id;
    public $item_id;
    public $url;
    public $host;
    public $first_view;
    public $last_view;
    public $view_count;
}