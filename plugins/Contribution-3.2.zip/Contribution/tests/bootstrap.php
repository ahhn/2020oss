<?php

define('CONTRIBUTION_PLUGIN_DIR', dirname(dirname(__FILE__)));
require_once dirname(dirname(CONTRIBUTION_PLUGIN_DIR)) . '/application/tests/bootstrap.php';
