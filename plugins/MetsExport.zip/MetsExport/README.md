# MetsExport
Omeka 2.1+ plugin allowing export of items and collections as .mets xml files

If you use this plugin, please take a moment to submit feedback about your experience, so we can keep making Omeka better: [User Survey](https://docs.google.com/forms/d/1fmq4w4fs8n0H7yVnSEEYuGd4vNAFFLlGCa6LCM0ZSIE/viewform?usp=send_form "User Survey")
