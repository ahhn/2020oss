# IntenseDebate
Embed Intense Debate comments on Omeka item and/or collection templates. Comments are moderated at [intensedebate.com](http://intensedebate.com/) (account required).
