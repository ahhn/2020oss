<?php

class SearchResultsImageView extends SearchResultsView
{
    function __construct()
    {
        parent::__construct();
    }
}