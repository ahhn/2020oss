<?php

class Table_ItemDuplicateCheckRule extends Omeka_Db_Table {}
