<?php
interface Ngram_SequenceFiller_SequenceFillerInterface
{
    public function getFilledSequence($start, $end);
}
