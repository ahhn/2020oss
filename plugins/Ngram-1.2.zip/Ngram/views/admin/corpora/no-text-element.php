<?php echo head(array('title' => 'Ngram', 'bodyclass'=>'show')); ?>
<h2>Text Element Not Set</h2>
<p>You must set a text element prior to using the Ngram plugin. Please go to
<a href="<?php echo url('plugins/config', array('name' => 'Ngram')); ?>">plugin
configuration</a> and select a text element.</p>
<?php echo foot(); ?>
