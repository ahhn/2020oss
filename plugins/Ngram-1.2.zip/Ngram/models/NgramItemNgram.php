<?php
class NgramItemNgram extends Omeka_Record_AbstractRecord
{
    public $id;
    public $ngram_id;
    public $item_id;
}
