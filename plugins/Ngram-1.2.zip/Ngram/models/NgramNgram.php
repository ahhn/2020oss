<?php
class NgramNgram extends Omeka_Record_AbstractRecord
{
    public $id;
    public $ngram;
    public $n;
}
