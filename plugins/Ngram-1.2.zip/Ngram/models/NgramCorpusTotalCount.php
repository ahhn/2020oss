<?php
class NgramCorpusTotalCount extends Omeka_Record_AbstractRecord
{
    public $id;
    public $corpus_id;
    public $n;
    public $sequenceMember;
    public $count;
}
