<?php
class NgramCorpusCount extends Omeka_Record_AbstractRecord
{
    public $id;
    public $corpus_id;
    public $ngram_id;
    public $count;
}
