Corrections
===========

Omeka plugin. Basic mechanism for public adding correction info to what exists

Plugin Status
-------------

Work in progress. A thing that I need for [US Museums Explorer](http://museums.hackingthehumanities.org/about). Not affiliated with my place of work. 

Configuration
-------------

Configuration lets you choose what elements in Omeka are correctable. A link to a correction page will let visitors
propose corrections to the elements selected in configuration. This lets you leave some elements not subject to correction,
but others that you choose will be.

Workflow
--------

The plugin will not delete or overwrite data. All accepted corrections appears as additional values for whatever elements
are available. After accepting a correction, you will be directed to the item page to review the data. From there, 
edit the item as needed in the usual way.
