<?php

class Corrections_View_Helper_ElementInput extends Omeka_View_Helper_ElementInput
{
    protected function _getControlsComponent() {
        return '';
    }
    
    protected function _getHtmlCheckboxComponent($inputNameStem, $isHtml) {
        return '';
    }
}