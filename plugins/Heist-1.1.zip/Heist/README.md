# plugin-Heist
Heist is a plugin to help the interaction between tabletop displays at a GLAM and mobile devices. It is only important to institutions using OmekaEverywhere.
