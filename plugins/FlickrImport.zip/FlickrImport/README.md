# FlickrImport
Allows Omeka admins to import sets of photos from Flickr along with their associated metadata

If you use this plugin, please take a moment to submit feedback about your experience, so we can keep making Omeka better: [User Survey](https://docs.google.com/forms/d/1zci311T6AxuJ8OUPEEVFvwL3-mFBbv4JlpWl7haABrs/viewform?usp=send_form "User Survey")
