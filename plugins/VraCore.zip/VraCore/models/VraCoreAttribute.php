<?php

class VraCoreAttribute extends Omeka_Record_AbstractRecord
{
    public $record_id;

    public $record_type;

    public $element_id;

    public $vra_element_id;

    public $name;

    public $content;
}
