<?php
/**
 * A simple_vocab_plus term entry row.
 *
 * @package SimpleVocabPlus
 */
class SvpTerm extends Omeka_Record_AbstractRecord
{
    public $id;
    public $vocab_id;
    public $term;
}
